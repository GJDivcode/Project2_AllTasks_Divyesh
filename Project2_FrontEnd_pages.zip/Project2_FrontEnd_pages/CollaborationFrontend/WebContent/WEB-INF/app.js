
var app=angular.module('myApp',['ngRoute','ngCookies']);

app.config(function($routeProvider) {
	$routeProvider
	
	.when('/',{
		templateUrl:'Home/home.html'
		
	})
	.when('/manageUser',{
		templateUrl:'Admin/manage_users.html',
		controller:'AdminController'
		
	})
	
	.when('/about',{
		templateUrl:'About/about.html',
		controller:'AboutController'
		
	})
	
	.when('/login',{
		templateUrl:'User/login.html',
		controller:'UserController'
		
	})
	
	.when('/register',{
		templateUrl:'User/register.html',
		controller:'UserController'
		
	})
	
	.when('/myProfile',{
		templateUrl:'User/my_profile.html',
		controller:'UserController'
		
	})
	
	/*
	 * ............Blog Mapping............
	 */
	
	.when('/create_blog',{
		templateUrl:'Blog/create_blog.html',
		controller:'BlogController'
		
	})
	
	.when('/list_blog',{
		templateUrl:'Blog/list_blog.html',
		controller:'BlogController'
		
	})
	
	.when('/view_blog',{
		templateUrl:'Blog/view_blog.html',
		controller:'BlogController'
		
	})
	
	
	/*
	 * .............Friend Mappings............
	 */
	
	.when('/add_friend',{
		templateUrl:'Friend/add_friend.html',
		controller:'FriendController'
		
	})
	
	.when('/search_friend',{
		templateUrl:'Friend/search_friend.html',
		controller:'FriendController'
		
	})
	
	.when('/view_friend',{
		templateUrl:'Friend/view_friend.html',
		controller:'FriendController'
		
	})
		/*
	 * ...............Chat_forum Mappings and job are left.................
	 */
	.otherwise({
		redirectTo:'/'
		
	});
	
	
});

app.run(function ($rootScope, $location, $cookieStore, $http){
	$rootScope.$on('$locationChangeStart', function (event, next, current){
		console.log("$locationChangeStart")
		var restrictedpage= $.inArray($location.path(),['/','/search_job','/view_blog'];
		console.log("restrictedpage:"+restrictedpage)
/*		var loggedIn = $rootScope.currentUser.userid;*/
		var loggedIn = $rootScope.currentUser.userid;
		
		console.log("loggedIn:"+loggedIn)
		
		if(!loggedIn)
		{
		if(restrictedpage){
			console.log("Navigating to login Page:")
			$location.path('/login');
			
		}	
		}
		else{
			var role=$rootScope.currentUser.role;
			var userRestricedPage = $.inArray($location.path(),["/post_job"])==0;
			
			if(userRestricedPage && role!='admin'){
				alert("you can not do this operation as you  are logged as:"+role)
				$location.path('/login');
				
			}
			
		}
		
	}
	);
		
		$rootScope.currentUser=$cookieStore.get('currentUser')||{};
		if($rootScope.currentUser){
			$http.defaults.headers.common['Authorization']='Basic'+$rootScope.currrentUser;
			
		}
		
});
